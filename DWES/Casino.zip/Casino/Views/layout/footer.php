<footer>
    <h2>Casino Footer</h2>
</footer>