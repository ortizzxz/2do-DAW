<html>

<head>
    <title>Casino Fiti</title>
</head>

<body>
    <?php
    require_once './Autoloader.php';
    require_once './Config/config.php';
    
    use Controllers\FrontController;
    FrontController::main();
    ?>
    
</body>

</html>