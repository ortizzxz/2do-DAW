<?php
    define('CONTROLLER_DEFAULT', 'BarajaController');
    define('ACTION_DEFAULT', 'mostrarBaraja');
    define('URL', 'http://localhost/instituto/DWES/Casino/');