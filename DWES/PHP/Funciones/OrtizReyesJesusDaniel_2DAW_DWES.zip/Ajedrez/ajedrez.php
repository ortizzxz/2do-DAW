<?php
    include "funciones.php";
?>

<html>
    <head>
        <title>Ajedrez</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <table>
            <?php creaTable(); ?>
        </table>
    </body>
</html>


