<?php
    require "formulario.php";
?>

<html>
<head>
    <title>Jugar a la Brisca</title>
</head>
<body>
    <?php imprimirFormulario()?> 
</body>
</html>